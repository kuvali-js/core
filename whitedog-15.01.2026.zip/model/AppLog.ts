import { Model } from '@nozbe/watermelondb';
import { field, text, readonly } from '@nozbe/watermelondb/decorators';

export default class AppLog extends Model {
  static table = 'app_logs';

  @field('schema_version') schemaVersion!: number;
  @text('session_id') session_id!: string; // Mapping auf sessionId im Schema
  @text('level') level!: string;
  @text('context') context!: string;
  @text('message') message!: string;
  @text('payload') payload!: string;
  @readonly @field('created_at') created_at!: number;
}