// services/InitializeService.ts
import * as Sentry from '@sentry/react-native';
import { i18n } from '../core/i18n/lib/I18nService';
import log from './IdentityService';

/**
 * Global application initialization.
 */
export const initializeApp = async (): Promise<void> => {

  //-------------------------------------
  // 1. Set Log Level
  const level = __DEV__ ? log.levels.DEBUG : log.levels.INFO;
  log.setLevel(level);

  //-------------------------------------
  // init logging to bugsink
  Sentry.init({
    dsn: process.env.EXPO_PUBLIC_BUGSINK_KEY,
    debug: true, // Useful to see if the upload works
  });

  //-------------------------------------
  // init translations
  // reads user chosen language or sets "en" as default
  await i18n.init("en")

  //-------------------------------------
  // 3. developer settings
  if (__DEV__) {
    console.log(`[Bootstrap] App initialized with log level ${log.getLevel()}: ${log.logLevelName()}`);
  }
};