// context/TranslationContext.tsx
import React, { createContext, ReactNode, useMemo, useState } from 'react';
import { i18n } from '../I18nService';

interface TranslationContextType {
  t: typeof i18n.t;
  locale: string;
  setLocale: (locale: string) => void;
  availableLocales: string[];
}

export const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

export const TranslationProvider = ({ children }: { children: ReactNode }) => {
  // Use the initial locale from the service as starting state
  const [locale, setLocaleState] = useState<string>(i18n.getLocale());

  const contextValue = useMemo(() => ({
    t: (key: any, args?: any) => i18n.t(key, args),
    locale,
    setLocale: (newLocale: string) => {
      i18n.setLocale(newLocale);
      setLocaleState(newLocale);
    },
    availableLocales: i18n.getAvailableLocales(),
  }), [locale]);

  return (
    <TranslationContext.Provider value={contextValue}>
      {children}
    </TranslationContext.Provider>
  );
};