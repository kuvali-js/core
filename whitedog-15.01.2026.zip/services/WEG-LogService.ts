import * as Sentry from '@sentry/react-native';
import Constants from 'expo-constants';
import * as Crypto from 'expo-crypto'; // Use expo-crypto for UUIDs
import * as SecureStore from 'expo-secure-store';
import log from 'loglevel';
import { Platform } from 'react-native';
import { supabase } from '../lib/supabase/supabase';
import { database } from '../model/database';


//#############################################################################
//### USER
//#############################################################################
// Key for encrypted storage
const SECURE_USER_ID_KEY = 'auth_user_id';

// Memory cache for the user ID to avoid repeated Supabase calls
let cachedUserId: string | null = null;
let isInitializing = false;

/**
 * Initializes the userId from SecureStore or Supabase.
 * Fetches the ID once and stores it in memory.
 * This is called once when the service is first called.
 */
const initUserId = async (): Promise<void> => {
  if (isInitializing) return;
  isInitializing = true;

  let id = null
  try {
    // 1. Try to get from encrypted local storage for fast startup
    id = await SecureStore.getItemAsync(SECURE_USER_ID_KEY);

    if (!id) {
      // 2. Fallback to Supabase if not in storage
      const { data } = await supabase.auth.getSession();
      id = data.session?.user?.id ?? null;
    }

    if (!id) {
      // 3. Generate a random UUID for this device instance
      id = `anon-${Crypto.randomUUID()}`;
    }

  } catch (error) {
    console.error('Failed to initialize userId in LogService', error);
  } finally {
    if (id) { // to avoid ts-error about "null"
      await SecureStore.setItemAsync('installation_id', id);
      setLogUser(id)
    }
    isInitializing = false;
  }
};

/**
 * Updates the user ID both in memory and in encrypted storage.
 * Call this after successful login or logout.
 */
export const setLogUser = async (id: string | null) => {
  cachedUserId = id;
  if (id) {
    await SecureStore.setItemAsync(SECURE_USER_ID_KEY, id);
    Sentry.setUser({ id });
  } else {
    await SecureStore.deleteItemAsync(SECURE_USER_ID_KEY);
    Sentry.setUser(null);
  }
};

// Trigger background initialization immediately
initUserId();


//#############################################################################
//### LOGING
//#############################################################################
// Log-Level as Array
export const LOG_LEVEL_NAMES = ['TRACE', 'DEBUG', 'INFO', 'WARN', 'ERROR', 'SILENT'] as const;
export type LogLevelName = typeof LOG_LEVEL_NAMES[number];

const getLevelName = (level: number): LogLevelName => { return LOG_LEVEL_NAMES[level] };
const logLevelName = (): LogLevelName => { return getLevelName(log.getLevel()) };
const logLevel = (): number => { return log.getLevel() };

// Interface to extend loglevel type.
interface LogExtensions {
  getLevelName: (level: number) => LogLevelName;
  logLevelName: () => LogLevelName;
  logLevel: () => number;
  devFatal(message: string, context?: string): void;
  LOG_LEVEL_NAMES: typeof LOG_LEVEL_NAMES;
}

const originalFactory = log.methodFactory;

log.methodFactory = (methodName, logLevel, loggerName) => {
  const rawMethod = originalFactory(methodName, logLevel, loggerName);

  return (message, ...args) => {
    // Standardize metadata
    const metadata = {
      args: args,
      timestamp: new Date().toISOString(),
      userId: cachedUserId,
      app: {
        version: Constants.expoConfig?.version,
        build: Platform.select({
          ios: Constants.expoConfig?.ios?.buildNumber,
          android: Constants.expoConfig?.android?.versionCode?.toString(),
        }),
      },
      device: {
        os: Platform.OS,
        os_version: Platform.Version,
        model: Constants.deviceName,
      }
    };

    const levelUpper = methodName.toUpperCase();

    // 1. Bugsink / Sentry Logic
    if (levelUpper === 'ERROR') {
      // Immediate remote report for errors
      const errorObject = message instanceof Error ? message : new Error(message);
      Sentry.captureException(errorObject, { extra: metadata });
      console.log('Error logging to bugsink done.', message)
    } else {
      // Local buffer only for non-errors
      Sentry.addBreadcrumb({
        category: 'log',
        message: String(message),
        level: methodName as Sentry.SeverityLevel,
        data: metadata,
      });
      console.log('Non-Error logging to bugsink done:', message)
    }

    // 2. WatermelonDB Local-First Persistence
    // We don't await here to keep the app execution non-blocking
    database.write(async () => {
      await database.get('app_logs').create((entry: any) => {
        const now = Date.now();
        entry.userId = metadata.userId;
        entry.level = levelUpper;
        entry.message = String(message);
        entry.payload = JSON.stringify(metadata);
        entry.createdAt = now;
        entry.updatedAt = now;
      });
      console.info('Local logging to watermelon done.')
    }).catch(
      (err) => {
        console.error('Local logging failed.', err)
    });

    // 3. Console Output
    rawMethod(message, ...args);
  };

  /**
   * Behandelt kritische Framework-Fehler.
   * In DEV: Wirft einen harten Error (RedBox).
   * In PROD: Loggt eine Warnung, damit die App nicht abstürzt.
   */
  public devFatal(message: string, context?: string): void {
    const fullMessage = `[Kivuli DX] ${context ? `${context}: ` : ''}${message}`;

    if (__DEV__) {
      throw new Error(fullMessage);
    } else {
      this.warn(fullMessage);
    }
  }
}

// Apply the factory changes
log.setLevel(log.getLevel());

/**
 * Extend the log instance with the custom method.
 * keep the original loglevel intact while adding getLevelName
 */
const LogService = Object.assign(log, {
  getLevelName,
  logLevelName,
  logLevel,
  LOG_LEVEL_NAMES,
}) as typeof log & LogExtensions;

export default LogService;
