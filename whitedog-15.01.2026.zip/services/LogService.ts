// core/services/LogService.ts
//*****************************************************************************
/** ### Custom Plugin for LogLevel
 * Service class that handles application-wide logging and error handling,
 * ---
 * LogLevel class to add custom functions to LogLevel.
 *
 * 1. Plugin for logging to:
 * - send errors to BugSink (Sentry protocol)
 * - WatermelonDb for sync logs to clou
 *
 * 2. Defining @Log Decorator
 * To include in every call to get:
 * - function name
 * - class name
 * (or log this once at function entry and exit)
 *
 *****************************************************************************
 * @todo
 * - V2.0 - implement a buffer for log messages of database layer, which is init is called before log
 *****************************************************************************/

import { Platform } from 'react-native';
import * as Sentry from '@sentry/react-native';
import Constants from 'expo-constants';
import React from 'react';
import log, { Logger } from 'loglevel';

import { database } from '../model/database';
import identityService from './IdentityService';
import { version as appVersion } from '@/package.json';

//#############################################################################
//### LOGGING
//#############################################################################

// Log-Level as array
export const LOG_LEVEL_NAMES = [ 'TRACE', 'DEBUG', 'INFO', 'WARN', 'ERROR', 'SILENT' ] as const;
// get Log-Level as string
export type LogLevelName = typeof LOG_LEVEL_NAMES[number];

// Interface to extend loglevel type.
interface LogExtensions {
  getLevelName: (level: number) => LogLevelName;
  logLevelName: () => LogLevelName;
  logLevel:     () => number;
  devFatal(message: string, context?: string): void;
  LOG_LEVEL_NAMES: typeof LOG_LEVEL_NAMES;
}

//*****************************************************************************
/** ### LogLevel wrapper class
 * Service class that handles application-wide logging,
 * integrating with BugSink (Sentry protocol) for remote error tracking and
 * WatermelonDB for local log persistence and then replicated to Supabase.
 *****************************************************************************/
class LogService {
  private isInitialized = false;
  private sessionId: string | null = null;  // persistence between every call to log
  private userId: string | null = null;     // is set after IdentityService is initialised (eventually after init of LogService)

  constructor() {
    this.sessionId = Constants.sessionId;
    this.setupFactory()   // create a wrapper for LogLevel
  }

  //***************************************************************************
  /** ### Initialise the session
   * Logs session, app and device data once:
   * - session,
   * - userid, role and
   * - device and app data
  ****************************************************************************/
  public async init() {
    if (this.isInitialized) return;

    const sessionHeader = {
      schemaVersion: 1, // Metadata Schema Version
      sessionId: this.sessionId,
      user: {
        uid: identityService.getUserId(),
        role: "",
      },
      version: {
        app: appVersion,
        build: Platform.select({
          ios: Constants.expoConfig?.ios?.buildNumber,
          android: Constants.expoConfig?.android?.versionCode?.toString(),
        }),
        expo: Constants.expoConfig?.version,
        react: React.version,
        rn: `${Platform.constants?.reactNativeVersion?.major}.${Platform.constants?.reactNativeVersion?.minor}`
      },
      device: {
        os: Platform.OS,
        osVersion: Platform.Version,
        model: Constants.deviceName,
      }
    };

    // Write common "Header"-metadata at start of session
    await this.persistToDatabase('SYSTEM', 'Session Start', { sessionHeader });

    // set static data as tags in Sentry
    Sentry.setTags({
      sid: this.sessionId,
      app_version: sessionHeader.version.app,
      os: sessionHeader.device.os
    });

    this.isInitialized = true;
  }

  //***************************************************************************
  /** ### LogLevel Plugin
   * Extends the loglevel factory to inject metadata and
   * handle multi-channel output
   * - BugSink,
   * - WatermelonDB,
   * - Console
   ***************************************************************************/
  private setupFactory() {
    const originalFactory = log.methodFactory;

    log.methodFactory = (methodName, logLevel, loggerName) => {
      const rawMethod = originalFactory(methodName, logLevel, loggerName);

      // --- create standard meta data record ---
      return async (message, ...args) => {
        // Standardize metadata
        const metadata = {
          schemaVersion: 1, // Metadata Schema Version
          sessionId: this.sessionId,
          args: args, // the message(s) to be logged
        };

        const levelUpper = methodName.toUpperCase();

        // --- log errors to Bugsink ----
        if (levelUpper === 'ERROR') {
          // Immediate remote report for errors
          const errorObject = message instanceof Error ? message : new Error(String(message));
          Sentry.captureException(errorObject, { extra: metadata });
          console.debug('Error logging to bugsink done.', message);
        } else {
          // --- put non-errors into BugSink/Sentry breadcrumns ---
          // Local buffer for non-errors
          Sentry.addBreadcrumb({
            category: 'log',
            level: methodName as Sentry.SeverityLevel,
            message: String(message),
            data: metadata,
          });
          console.debug('Non-Error logging to bugsink done:', message);
        }

        // --- log everything in WatermelonDB for offline-first persistence
        await this.persistToDatabase(levelUpper, message, { metadata });

        // --- Console Output -----------
        rawMethod(message, ...args);
      };
    };

    // Apply the factory changes
    log.setLevel(log.getLevel());
  }

  //#############################################################################
  /** ### Write log entry to local device database
   * Log to WatermelonDB for offline-first persistence
   *****************************************************************************/
  private async persistToDatabase(level: string, message: string, metadata: any) {
    // async for non-blocking execution
    database.write(async () => {
      await database.get('app_logs').create((entry: any) => {
        const now = Date.now();
        entry.sessionId = metadata.sessionId;
        entry.level = level;
        entry.message = String(message);
        entry.payload = JSON.stringify(metadata);
        entry.createdAt = now;
        entry.updatedAt = now;
      });
      console.debug('Local logging to watermelon done.');
    }).catch((err) => {
      console.error('Local logging failed.', err);
    });
  }


  //#############################################################################
  //### PUBLIC API
  //#############################################################################

  //*****************************************************************************
  /** ### Handle development errors
   * - dev:  fail with an error
   * - prod: log a warning and continue
   *****************************************************************************/
  public devFatal(devMessage: string, prodMessage: string, context?: string): void {

    if (__DEV__) {
      const fullMessage = `[Kivuli DX] ${context ? `${context}: ` : ''}${devMessage}`;
      throw new Error(fullMessage);
    } else {
      const fullMessage = `[Kivuli] ${context ? `${context}: ` : ''}${prodMessage}`;
      this.warn(fullMessage);
    }
  }

  // transparent access to LogLevel functions
  public trace      = log.trace;
  public debug      = log.debug;
  public info       = log.info;
  public warn       = log.warn;
  public error      = log.error;
  public setLevel   = log.setLevel;
  public getLevel   = log.getLevel;
  public getLogger  = log.getLogger;
  public getLoggers = log.getLoggers;
}

// Export as Singleton
const LogServiceInstance = new LogService();
export default LogServiceInstance;


//### END #####################################################################