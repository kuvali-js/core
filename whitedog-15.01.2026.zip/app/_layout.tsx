console.log ("START WHITE DOG APP ######################")

import { Buffer } from 'buffer';
import { install } from 'react-native-quick-crypto';
// global assignment BEFORE everything else.
global.Buffer = Buffer;
install();

import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';

import { useColorScheme } from '@/hooks/useColorScheme';
import * as SplashScreen from 'expo-splash-screen';
import { TranslationProvider } from '../core/i18n/context/TranslationContext';
import { initializeApp } from '../services/InitializeService';

export const unstable_settings = {
  anchor: '(tabs)',
};

// keep splash screen
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const colorScheme = useColorScheme();
  const [ isReady, setIsReady ] = useState(false);

  useEffect(() => {
    async function prepare() {
      try {
        await initializeApp();
      } catch (e) {
        console.warn(e);
      } finally {
        setIsReady(true);
        await SplashScreen.hideAsync();
      }
    }

    prepare();
  }, []);

  // show splash screen during init
  if (!isReady) {
    return null;
  }

  return (
    <TranslationProvider>
      <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
        <Stack>
          <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
          <Stack.Screen name="modal" options={{ presentation: 'modal', title: 'Modal' }} />
        </Stack>
        <StatusBar style="auto" />
      </ThemeProvider>
    </TranslationProvider>
  );
}

