// /core/i18n/I18nService.ts
/**********************************************************
 * ### I18n Translations
 **********************************************************/
import { log, Log } from '@kivuli/core';

//***************************************************************************
// the i18n implementation
import { initI18n, type DotPathsFor, type Params, type Translations } from "./lib/i18n";
import * as SecureStore from 'expo-secure-store';     // persistence of the language between app starts

//***************************************************************************
/** ### Returns all strings in set language
 * Service class that encapsulates and abstracts the implementation of the i18n logic.
 * @core-todo
 *  Import and set the languages you use in Translations list.
 * @functions
 * - init()
 * - t()
 * - getLocale()
 * - setLocale()
 * - getAvailableLocales()
 ****************************************************************************/
class I18nService {
  private static readonly CONTEXT: string = "i18n-Service"
  private engine: ReturnType<typeof initI18n> | null = null

  // Internal registry of available translations
  private translations: Translations = { };
  private currentLocale: string = "en";
  private readonly STORAGE_KEY  = 'user_language';

 //****************************************************************************
 /** ### Load or set the locale & init translations
  * Use locale already stored on device or set given one
  * Initializes the i18n service by
  * - loading the persisted locale
  * - or sets the given locale
  * - or sets first of the translation languages list
  * @returns string with set locale
  ****************************************************************************/
  @Log(CONTEXT)
  public async init(defaultLocale: string): Promise<string> {
    // --- validation -------------------
    const supported = this.getAvailableLocales()

    let errMsg = ""
    if (supported.length === 0) {
      errMsg = `Locale list is empty.`
    }
    if (!errMsg && (!defaultLocale || defaultLocale === "" || defaultLocale && supported.includes(defaultLocale))) {
      errMsg = `Invalid defaultLocale: "${defaultLocale}". Supported are: "${supported.join(', ')}"`
    }
    if (errMsg) {
      if (__DEV__) {
        throw new Error(errMsg)
      } else {
        defaultLocale = supported[ 0 ]
        log.warn(errMsg, `i18n.init: defaultLocale set to "${defaultLocale}"`)
      }
    }

    //-- set language -------------------
    let locale = defaultLocale

    try {
      // Load language from SecureStore
      let getLocale = await SecureStore.getItemAsync(this.STORAGE_KEY);

      if (!getLocale) {
        getLocale = defaultLocale;
        await SecureStore.setItemAsync(this.STORAGE_KEY, locale);
      }

      locale = this.setupLocale(getLocale);
    } catch (error) {
      locale = this.setupLocale(defaultLocale);
    }
    log.info(`i18n.init: defaultLocale set to "${defaultLocale}"`)
    return locale
  }

  /** ### Set locale and return the set locale
   */
  @Log(CONTEXT)
  private setupLocale(locale: string): string {
    this.engine = initI18n(locale, "en", this.translations)
    const setLocale = [...this.engine.orderedLocales][0]   // Set -> Array, first element
    this.currentLocale = setLocale
    return setLocale
  }

  //=====================================
  /**
   * Sets a new locale and re-initializes the engine.
   */
  public async setLocale(locale: string): Promise<void> {
    this.setupLocale(locale);
    await SecureStore.setItemAsync(this.STORAGE_KEY, locale);
  }

  public getLocale(): string {
    return this.currentLocale;
  }

  public getAvailableLocales(): string[] {
    return Object.keys(this.translations);
  }

  /**
   * Main translation method.
   */
  public t<S extends DotPathsFor>(key: S, args?: Params<S>): string {
    if (!this.engine) return key;
    return (this.engine.t as any)(key, args);
  }

}

export const i18n = new I18nService();

//### END #####################################################################