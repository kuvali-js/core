import { Database } from '@nozbe/watermelondb';
import SQLiteAdapter from '@nozbe/watermelondb/adapters/sqlite';
import AppLog from './AppLog';
import Records from './EncryptedRecord';
import { watermelonSchema } from './watermelonSchema';

const adapter = new SQLiteAdapter({
  dbName: 'white_dog_db', // name of SQLite file on device
  schema: watermelonSchema,
  // migrations,
  jsi: true,
});

export const database = new Database({
  adapter,
  modelClasses: [Records, AppLog],
});