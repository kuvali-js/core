import { appSchema, tableSchema } from '@nozbe/watermelondb';

export const watermelonSchema = appSchema({
  version: 3, // Increment version for schema changes
  tables: [
    tableSchema({
      name: 'encrypted_records',
      columns: [
        { name: 'user_id', type: 'string', isIndexed: true },
        { name: 'encrypted_data', type: 'string' },
        { name: 'category', type: 'string', isIndexed: true },
        { name: 'initialization_vector', type: 'string' },
        { name: 'created_at', type: 'number', isIndexed: true },
        { name: 'updated_at', type: 'number', isIndexed: true },
      ],
    }),
    tableSchema({
      name: 'app_logs',
      columns: [
        { name: 'created_at', type: 'number', isIndexed: true },
        { name: 'schema_version', type: 'number' },
        { name: 'session_Id', type: 'string' },
        { name: 'level', type: 'string', isIndexed: true },
        { name: 'context', type: 'string', isIndexed: true },
        { name: 'message', type: 'string' },
        { name: 'payload', type: 'string' },
      ],
    }),
  ],
});
