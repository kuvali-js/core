import { useContext } from 'react';
import { TranslationContext } from '../context/TranslationContext';

/**
 * Access the translation context.
 * Provides t(), locale, setLocale, and availableLocales.
 */
export const useI18n = () => {
  const context = useContext(TranslationContext);

  if (!context) {
    throw new Error('Kivuli i18n not initialized. Use <CoreProvider> in App.js.');
  }

  return context;
};