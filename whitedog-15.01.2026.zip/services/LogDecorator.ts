//LogService/decorator/LogDecorator.ts
import * as logService from './LogService'
import LogServiceInstance from './LogService'

//#############################################################################
//### DECORATOR
//#############################################################################


/*****************************************************************************
* ### \@Log-Decorator
 * Automatically logs
 *****************************************************************************/
export function Log(originalMethod: any, context: ClassMethodDecoratorContext) {
  const methodName = String(context.name);

  return function (this: any, ...args: any[]) {
      const className = this.constructor.name;
      const logger = logService.getLogger(className);

      logger.debug(`[${className}:${methodName}] called with:`, args);

      try {
          const result = originalMethod.apply(this, args);
          if (result instanceof Promise) {
            return result.then((res) => {
              logger.debug(`✅ [${className}:${methodName}] resolved:`, res);
              return res;
            });
          }
          return result;
      } catch (error) {
          logger.error(`❌ [${className}:${methodName}] failed`, error);
          throw error;
      }
  };
}

// Named export for the Decorator to use it as @Log
export const Log = LogServiceInstance.Log.bind(LogServiceInstance);

//### END #####################################################################