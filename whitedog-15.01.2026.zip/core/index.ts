// core/index.ts
export { CoreProvider } from './context/CoreProvider';
export * from './i18n/index';
export * from './log/index';

/** * Future exports:
 * export { useDatabase } from './database/useDatabase';
 * export { useAuth } from './auth/useAuth';
 */
