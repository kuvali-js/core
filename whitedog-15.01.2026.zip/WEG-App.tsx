// App.tsx
import React from 'react';
import { ExpoRoot } from 'expo-router';
import { CoreProvider } from '@kivuli/core';

import { log as logService, i18n as i18nService } from '@kivuli/core';

const ctx = require.context('./app');

/**********************************************************
 * ### load translation files for every language
 *
 * @core-todo - add languages here once to have them globaly in the code and your app
 *
 **********************************************************/
import en from '@kivuli/translations/en'
import sw from '@kivuli/translations/sw'


/**********************************************************
 * ### Init & Config Core Modules
 **********************************************************/
async function bootstrap() {
  const config = {
    i18n: { translations: [en, sw] }
  }

  // start logger first (Sentry & console are working now)
  await logService.init()
  logService.debug("App bootstrapping starting...")

  try {
    logService.debug("init databaseService")
    // await databaseService.init();

    logService.debug("Notify logSerice it can access database now")
    logService.setDbReady()

    logService.debug("init i18nService")
    await i18nService.init(config.i18n.translations)

    logService.debug("init identitiyService")
    // await identitiyService.init();
    // logService.setUserId(identitiyService.userId, identitiyService.role)

  } catch (error) {
    // Hier greift der Logger bereits, auch wenn die DB vielleicht nie bereit wurde!
    logService.error("Fatal error during bootstrap", error);
  }
}

/**********************************************************
 * ### Gentlemen, start your App...
 **********************************************************/
await bootstrap()

export default function App() {
  return (
    <CoreProvider>
      <ExpoRoot context={ctx} />
    </CoreProvider>
  )
}