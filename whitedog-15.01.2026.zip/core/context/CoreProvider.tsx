import React from 'react';
import { TranslationProvider } from '../i18n/context/TranslationContext';

export const CoreProvider = ({ config, children }: any) => {
  return (
    <TranslationProvider>
      {children}
    </TranslationProvider>
  );
};